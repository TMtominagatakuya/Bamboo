package jp.tcmobile.bamboo.controller;

import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import jp.tcmobile.bamboo.model.Category;
import jp.tcmobile.bamboo.model.Test;
import jp.tcmobile.bamboo.repository.CategoryRepository;
import jp.tcmobile.bamboo.service.TestServiceImpl;
import jp.tcmobile.bamboo.service.UserDetail;

@Controller
@SessionAttributes(names="reqForm")
public class TestController {
	
	@Autowired
	TestServiceImpl testServiceImpl;
	
	//Service繧堤怐逡･縺励※Repository繧堤峩謗･蜿ら�ｧ縲�
	@Autowired
	CategoryRepository categoryRepository;

	//home逕ｻ髱｢�ｼ壹ユ繧ｹ繝井ｸ�隕ｧ縺ｮ1繝壹�ｼ繧ｸ逶ｮ繧定｡ｨ遉ｺ縺吶ｋ
	@GetMapping(value= {"admin/test","/admin/test/testlist"})
	public ModelAndView showTestList() {
		return new ModelAndView("redirct:/admin/test/testlist/page1");
	}
	
	//繝励Ξ繝薙Η繝ｼ逕ｻ髱｢縲Ｊd蜈･蜉帙〒隧ｲ蠖薙ユ繧ｹ繝医�ｮ繝励Ξ繝薙Η繝ｼ縺後∩繧峨ｌ繧九��
	@GetMapping("admin/test/testpreview{id}")
	public ModelAndView showTest(ModelAndView mav, @AuthenticationPrincipal UserDetail userDetail, @PathVariable("id") String id) {
		mav.setViewName("admin/test/testpreview");
		//萓句､門�ｦ逅�繧偵☆繧九％縺ｨ
		Test test = testServiceImpl.findTestById(Integer.parseInt(id));
		mav.addObject(test);
		return mav;
	}

	//Page驕ｷ遘ｻ逕ｨ
	@GetMapping("admin/test/testlistpage{pageId}")
	public ModelAndView showPageTest(ModelAndView mav, @PathVariable("pageId") String pageId ){
		Page<Test> tests = testServiceImpl.getTestPageList(Integer.parseInt(pageId));
		mav.addObject("value", tests);
		mav.setViewName("admin/test/testlist");
		return mav;
	}

	
	@GetMapping("admin/test/testlist?category_id{category_id}/")
	public ModelAndView showTestByCategory(@PathVariable("category_id") String category_id ){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirct:/admin/test/testlist?category_id"+category_id+"/page1");
		return mav;
	}

	@GetMapping("admin/test/testlist?category_id{category_id}/page{pageId}")
	public ModelAndView showPageTestByCategory(
			ModelAndView mav,
			@PathVariable("category_id") int category_id,
			@PathVariable("pageId") int pageId){;
			Page<Test> tests = testServiceImpl.getTestPageListByCategory(pageId, category_id);
			mav.addObject("value", tests);
			mav.setViewName("/admin/test/testlist");
			return mav;
	}
	
    @GetMapping("admin/test/testlist?category_id{old_category_id}?category_id{new_category_id}/")
    public ModelAndView movePageTestByCategory(String old_category_id, String new_category_id) {
            return new ModelAndView("redirect:/admin/test/testlist?category_id{new_category_id}/page1");
    }

    @GetMapping("admin/test/testlist?category_all")
    public ModelAndView showTestByCategoryAll(ModelAndView mav) {
        return new ModelAndView("redirect:/admin/test/testlist/page1");
    }

	//繝�繧ｹ繝井ｽ懈�舌�ｻ邱ｨ髮�縺ｫ縺翫￠繧句撫鬘瑚ｿｽ蜉�縺ｮ讖溯�ｽ
	@RequestMapping(value= {"admin/test/addtest", "admin/test/edittest"}, params={"addProblem"})
	public ModelAndView addProblem(Test test, ModelAndView mav) {
		testServiceImpl.addProblem(test);
		mav.addObject("test", test);
		return mav;
	}
	
	//繝�繧ｹ繝井ｽ懈�舌�ｻ邱ｨ髮�縺ｫ縺翫￠繧句撫鬘悟炎髯､縺ｮ讖溯�ｽ
	@RequestMapping(value= {"admin/test/addtest", "admin/test/edittest"}, params={"removeProblem"})
	public ModelAndView removeProblem(
			Test test, 
			final HttpServletRequest req, ModelAndView mav) {
		int pId = Integer.valueOf(req.getParameter("removeProblem"));
		test.getProblemList().remove(pId);
		return mav;
	}

	//繝�繧ｹ繝井ｽ懈�舌�ｻ邱ｨ髮�縺ｫ縺翫￠繧矩∈謚櫁い霑ｽ蜉�縺ｮ蜃ｦ逅�
	@RequestMapping(value= {"admin/test/addtest", "admin/test/edittest{id}"}, params={"addChoice"})
	public ModelAndView addChoice(Test test, ModelAndView mav, HttpServletRequest req) {
		int pId = Integer.valueOf(req.getParameter("addChoice"));
		testServiceImpl.addChoice(test.getProblemList().get(pId));
		mav.addObject("test", test);
		return mav;
	}

	//繝�繧ｹ繝井ｽ懈�舌�ｻ邱ｨ髮�縺ｫ縺翫￠繧矩∈謚櫁い蜑企勁縺ｮ蜃ｦ逅�
	@RequestMapping(value= {"admin/test/addtest", "admin/test/edittest{id}"}, params={"removeChoice"})
	public ModelAndView removeChoice(Test test, ModelAndView mav, HttpServletRequest req) {
		// = Integer.valueOf(req.getParameter("addChoice"));
		List<String> idList = Arrays.asList(req.getParameter("removeChoice").split(","));
		int pId = Integer.parseInt(idList.get(0));
		int cId = Integer.parseInt(idList.get(1));
		test.getProblemList().get(pId).getChoiceList().remove(cId);
		mav.addObject("test", test);
		return mav;
	}

	//繝�繧ｹ繝育ｷｨ髮�逕ｻ髱｢縲ょｽ楢ｩｲID縺ｮ繝�繧ｹ繝医ｒ邱ｨ髮�縺吶ｋ縲�
	@GetMapping("admin/test/edittest{id}")
	public ModelAndView showEditTest(ModelAndView mav, @PathVariable("id") String id) {
		mav.setViewName("admin/test/edittest");
		//萓句､門�ｦ逅�繧偵☆繧九％縺ｨ
		Test test = testServiceImpl.findTestById(Integer.parseInt(id));
		mav.addObject(test);
		// ViewName縺ｯ莉ｮ鄂ｮ縺�
		return mav;
	}

	//テスト作成・編集後の、確認画面への遷移処理
	@RequestMapping(value= {"admin/test/addTest", "admin/test/edittest{id}"}, params={"TestConfirm"})
	public ModelAndView saveEditedTest(@ModelAttribute("test") @Validated Test test, BindingResult result, ModelAndView mav) {
		Category c = categoryRepository.findById(test.getCategory().getId()).orElse(null);
		boolean notEmpty = testServiceImpl.checkEmpty(test.getProblemList(), mav);
		test.getCategory().setName(c.getName());
		if(!result.hasErrors() && notEmpty == true) {
			mav.setViewName("admin/test/testconfirm");
			mav.addObject("test", test);
		} else {
			mav.addObject("msg", "sorry, error is occured...");
		}
		return mav;
	}
	
	//蝠城｡御ｽ懈�千判髱｢
	@GetMapping("admin/test/addtest")
	public ModelAndView showAddTest(ModelAndView mav) {
		mav.setViewName("admin/test/addtest");
		Test test = testServiceImpl.emptyTest();
		mav.addObject("test", test);
		return mav;
	}
	
	
	//遒ｺ隱咲判髱｢縺ｧ菴懈�舌�ｻ譖ｴ譁ｰ繝懊ち繝ｳ繧呈款荳九☆繧九→縲．B縺ｫ險倬鹸縺励�”ome逕ｻ髱｢縺ｫ謌ｻ繧�
	//id縺悟ｭ伜惠縺吶ｋ縺ｨ縺阪�ｯUpdate縲√↑縺代ｌ縺ｰ譁ｰ隕冗匳骭ｲ縺ｮ蜃ｦ逅�繧定ｿｽ險倥☆繧九％縺ｨ縲�
	@PostMapping("admin/test/testconfirm")
	public ModelAndView saveConfirmedTest(Test test) {
		Test t = test;
		testServiceImpl.assemble(t);
		testServiceImpl.saveTest(t);
		return new ModelAndView("redirect:admin/test/testlist/page1");
	}
	
	//繧ｫ繝�繧ｴ繝ｪ繝ｼ縺ｮ蛻晄悄蛟､蜈･蜉帙�ゅき繝�繧ｴ繝ｪ繝ｼ繝�繝ｼ繝悶Ν縺檎ｩｺ縺｣縺ｽ縺ｧ縺ゅｋ縺薙→縺悟燕謠舌〒縺ゅｋ縲�
//	@PostConstruct
//	public void init(){
//		Category java = new Category();
//		java.setName("Java");
//		categoryRepository.saveAndFlush(java);
//		Category sql = new Category();
//		sql.setName("SQL");
//		categoryRepository.saveAndFlush(sql);
//		Category javascript = new Category();
//		javascript.setName("Javascript");
//		categoryRepository.saveAndFlush(javascript);
//		Category others = new Category();
//		others.setName("縺昴�ｮ莉�");
//		categoryRepository.saveAndFlush(others);
//	}
	
	@GetMapping("admin/test/deletetest{id}")
	public ModelAndView confirmDeleateTest(Test test, @PathVariable("id") int id) {
		ModelAndView mav = new ModelAndView("admin/test/deletetest");
		test = testServiceImpl.findTestById(id);
		mav.addObject(test);
		return mav;
	}
	

	
	//蜑企勁遒ｺ隱咲判髱｢竊貞炎髯､蜃ｦ逅�縲�//0626tom
	@PostMapping("admin/test/deletetest{id}")
	public ModelAndView deleteTest(Test test, @PathVariable("id") int id) {
		testServiceImpl.deleteTestByid(id);
		//DB縺九ｉ蜑企勁縺励◆縺�蝣ｴ蜷医�ｯ荳玖ｨ倥�ｮ繝｡繧ｽ繝�繝峨ｒ蛻ｩ逕ｨ縺吶ｋ
		//testServiceImpl.deleteTestByidFromDB(id);	
		return new ModelAndView("redirect:admin/test/testlist/page1");
	}
	
	
	

}