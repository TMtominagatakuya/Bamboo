package jp.tcmobile.bamboo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jp.tcmobile.bamboo.model.Article;
import jp.tcmobile.bamboo.model.Authorization;
import jp.tcmobile.bamboo.model.Test;
import jp.tcmobile.bamboo.model.Authorization.Role;
import jp.tcmobile.bamboo.model.User;
import jp.tcmobile.bamboo.repository.UserRepository;
import jp.tcmobile.bamboo.service.TestServiceImpl;
import jp.tcmobile.bamboo.service.UserDetail;

@Controller
public class UserController {

	@Autowired
	TestServiceImpl testServiceImpl;
	
	@Autowired
	UserRepository userRepository;

	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
    @GetMapping("/index")
    public ModelAndView showHome( @AuthenticationPrincipal UserDetail userDetail){
        User user =userRepository.findByAcountName(userDetail.getUsername());
        ModelAndView mav = new ModelAndView();
        for(Authorization auth : user.getAuthorizationSet()) {
        	if(auth.getRole()==Role.admin) {
        		mav.setViewName("redirect:/admin/test/testlist/page1");
        	}
        	else if(auth.getRole()==Role.staff) {
        		mav.setViewName("/user/ArticleList");
        	}
        	else {
        		//後で失敗用のビューを追加
        		mav.setViewName("/error");
        	}
        }
        return mav;
    }
	
	
	// ユーザ一覧画面
	@GetMapping("/UsersList")
	public ModelAndView showUsersList(ModelAndView mav) {
		mav.setViewName("UsersList");
		return mav;
	}
	
	// ユーザ新規登録画面
		@GetMapping("/UsersAdd")
		public ModelAndView showUsersAdd(ModelAndView mav) {
			mav.setViewName("UsersAdd");
			return mav;
		}
	
	// ユーザ―編集画面
//		@GetMapping("/UsersEdit")
//		public ModelAndView showUsersEdit(ModelAndView mav) {
//			mav.setViewName("UsersEdit");
//			return mav;
//		}

}