package jp.tcmobile.bamboo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;
import jp.tcmobile.bamboo.model.Article;
import jp.tcmobile.bamboo.model.Authentication;
import jp.tcmobile.bamboo.model.User;
import jp.tcmobile.bamboo.repository.UserRepository;
import jp.tcmobile.bamboo.service.ArticleServiceImpl;
import jp.tcmobile.bamboo.service.UserDetail;
@Controller
public class ArticleController {
    @Autowired 
    ArticleServiceImpl articleServiceImpl;
    
    @Autowired 
    UserRepository userRepository;

    @GetMapping("/user")
    public ModelAndView showUserPageTest(ModelAndView mav){
    	int pageId = 1;
        Page<Article> articles = articleServiceImpl.getArticlePageList(pageId);
        mav.addObject("value", articles);
        mav.setViewName("ArticleList");
        return mav;
    }
    
    //ユーザIDの処理
    @GetMapping("/user/")
    public ModelAndView showUserArticle(ModelAndView mav, @AuthenticationPrincipal UserDetail userDetail){
        User user =userRepository.findByAcountName(userDetail.getUsername());
    	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_id(1, user.getId());
        mav.addObject("value", articles);
        mav.setViewName("ArticleList");
        return mav;
    }
    
    @GetMapping("/user{userId}/page{pageId}")
    public ModelAndView showUserPageTest(ModelAndView mav, @PathVariable("pageId") int pageId, @PathVariable("userId") int userId){
        Page<Article> articles = articleServiceImpl.getArticlePageListByUser_id(pageId,userId);
        mav.addObject("value", articles);
        mav.setViewName("ArticleList");
        return mav;
    }


    @GetMapping("/article{id}")
    public ModelAndView showArticle(ModelAndView mav, @PathVariable("id") int id){
        Article article = articleServiceImpl.getArticleById(id);
        mav.addObject("article", article);
        mav.setViewName("Article");
        return mav;
    }
    
    //ユーザID、カテゴリーを条件に問題抽出
    @GetMapping("/user{userId}/category_id{category_id}/")
    public ModelAndView showUserArticleByCategory(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("category_id") int category_id){;
        	int page=1;//1ページ目から
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategory(page, userId, category_id);
            mav.addObject("value", articles);
            mav.addObject("type","articles");
            
            mav.setViewName("ArticleList");
            return mav;
    }
    

    
  //ユーザID、カテゴリーを条件に問題抽出した結果のページ遷移する機能
    @GetMapping("/user{userId}/category_id{category_id}/page{pageId}")
    public ModelAndView showUserPageArticleByCategory(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("category_id") int category_id,
    		@PathVariable("pageId") int pageId){;
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategory(pageId, userId, category_id);
            mav.addObject("value", articles);
            mav.setViewName("ArticleList");
            return mav;
    }
    
    //カテゴリーからカテゴリーへ遷移する機能
    @GetMapping("/user{userId}/category_id{old_category_id}/category_id{new_category_id}/")
    public ModelAndView movePageTestByCategory(@PathVariable("userId") int userId,@PathVariable("new_category_id")  String new_category_id) {
            return new ModelAndView("redirect:/user{userId}/category_id{new_category_id}/") ;
    }
    
    //ステータスからステータスへ遷移する機能
    @GetMapping("/user{userId}/status_id{old_status_id}/status_id{new_status_id}/")
    public ModelAndView movePageTestByStatusId(@PathVariable("userId") int userId, @PathVariable("new_status_id")String new_status_id) {
            return new ModelAndView("redirect:/user{userId}/status_id{new_status_id}/") ;
    }
    
    //ステータスとカテゴリーの順番入れ替え status_id/category_id → category_id/status_id
    @GetMapping("/user{userId}/status_id{status_id}/category_id{category_id}/")
    public ModelAndView swapCategoryAndStatusId1(@PathVariable("userId") String userId, String old_status_id, String new_status_id) {
            return new ModelAndView("redirect:/user{userId}/category_id/status_id{status_id}/") ;
    }
    
    //ステータスとカテゴリーの順番入れ替え category_id/status_id/status_id → category_id/status_id
    @GetMapping("/user{userId}/category_id{category_id}/status_id{old_status_id}/status_id{new_status_id}/")
    public ModelAndView swapCategoryAndStatusId2(@PathVariable("userId") String userId, @PathVariable("category_id") String category_id, @PathVariable("new_status_id") String new_status_id) {
            return new ModelAndView("redirect:/user{userId}/category_id{category_id}/status_id{new_status_id}/")  ;
    }
    
    //ステータスとカテゴリーの順番入れ替え category_id/status_id/category_id → category_id/status_id
    @GetMapping("/user{userId}/category_id{old_category_id}/status_id{status_id}/category_id{new_category_id}/")
    public ModelAndView swapCategoryAndStatusId3(@PathVariable("userId") String userId, @PathVariable("new_category_id") String new_category_id, @PathVariable("status_id")String status_id) {
            return new ModelAndView("redirect:/user{userId}/category_id{new_category_id}/status_id{status_id}/")  ;
    }
    
    //ステータスとカテゴリの順番が逆だった場合実行
    @GetMapping("/user{userId}/status_id{status_id}/category_id{category_id}/page{pageId}/")
    public ModelAndView movePageTestByCategoryAndStatus(String status_id, String category_id) {
    	return new ModelAndView("redirect:/user{userId}/category_id{category_id}/status_id{status_id}/page{pageId}/");
    }
    
    //ユーザID、ステータスIDを条件に問題抽出
    @GetMapping("/user{userId}/status_id{status_id}/")
    public ModelAndView showUserArticleByStatus(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("status_id") int status_id){;
        	int page=1;//1ページ目から
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndStatusId(page, userId, status_id);
            mav.addObject("value", articles);
            mav.addObject("type","articles");
            
            mav.setViewName("ArticleList");
            return mav;
    }
    
    //ユーザID、ステータスIDを条件に問題抽出した結果のページ遷移する機能
    @GetMapping("/user{userId}/status_id{status_id}/page{pageId}")
    public ModelAndView showUserPageArticleByStatus(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("status_id") int status_id,
    		@PathVariable("pageId") int pageId){;
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategory(pageId, userId, status_id);
            mav.addObject("value", articles);
            mav.setViewName("ArticleList");
            return mav;
    }
    
    //ユーザID、ステータスID、カテゴリを条件に問題抽出した結果のページ遷移する機能
    @GetMapping("/user{userId}/category_id{category_id}/status_id{status_id}/")
    public ModelAndView showUserArticleByStatusAndCategory(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("status_id") int status_id,
    		@PathVariable("category_id") int category_id){;
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategoryAndStatusId(1, userId, category_id, status_id);
            mav.addObject("value", articles);
            mav.setViewName("ArticleList");
            return mav;
    }
    
    //ユーザID、ステータスID、カテゴリを条件に問題抽出した結果のページ遷移する機能
    @GetMapping("/user{userId}/category_id{category_id}/status_id{status_id}/page{pageId}")
    public ModelAndView showUserPageArticleByStatusAndCategory(
    		ModelAndView mav,
    		@PathVariable("userId") int userId,
    		@PathVariable("status_id") int status_id,
    		@PathVariable("category_id") int category_id,
    		@PathVariable("pageId") int pageId){;
        	Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategoryAndStatusId(pageId, userId, category_id, status_id);
            mav.addObject("value", articles);
            mav.setViewName("ArticleList");
            return mav;
    }
    

    


}