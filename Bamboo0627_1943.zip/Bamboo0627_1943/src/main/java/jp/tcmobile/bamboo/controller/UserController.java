package jp.tcmobile.bamboo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jp.tcmobile.bamboo.service.TestServiceImpl;

@Controller
public class UserController {

	@Autowired
	TestServiceImpl testServiceImpl;

	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	// ユーザ一覧画面
	@GetMapping("/UsersList")
	public ModelAndView showUsersList(ModelAndView mav) {
		mav.setViewName("UsersList");
		return mav;
	}
	
	// ユーザ新規登録画面
		@GetMapping("/UsersAdd")
		public ModelAndView showUsersAdd(ModelAndView mav) {
			mav.setViewName("UsersAdd");
			return mav;
		}
	
	// ユーザ―編集画面
//		@GetMapping("/UsersEdit")
//		public ModelAndView showUsersEdit(ModelAndView mav) {
//			mav.setViewName("UsersEdit");
//			return mav;
//		}

}