package jp.tcmobile.bamboo.service;

public interface UsersService {

}
