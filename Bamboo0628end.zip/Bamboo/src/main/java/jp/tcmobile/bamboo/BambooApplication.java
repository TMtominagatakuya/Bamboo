package jp.tcmobile.bamboo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BambooApplication {

	public static void main(String[] args) {
		SpringApplication.run(BambooApplication.class, args);
	}
}
