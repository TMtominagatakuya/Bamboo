package jp.tcmobile.bamboo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.tcmobile.bamboo.model.Choice;




public interface ChoiceRepository extends JpaRepository<Choice, Integer> {
}
