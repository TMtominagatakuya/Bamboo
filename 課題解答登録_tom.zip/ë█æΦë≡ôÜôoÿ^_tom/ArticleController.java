package jp.tcmobile.bamboo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import jp.tcmobile.bamboo.model.Article;
import jp.tcmobile.bamboo.model.User;
import jp.tcmobile.bamboo.model.UserAnswer;
import jp.tcmobile.bamboo.model.Problem;
import jp.tcmobile.bamboo.model.Authorization.Role;
import jp.tcmobile.bamboo.model.Choice;
import jp.tcmobile.bamboo.repository.ChoiceRepository;
import jp.tcmobile.bamboo.repository.UserRepository;
import jp.tcmobile.bamboo.service.UserDetail;
import jp.tcmobile.bamboo.service.ArticleServiceImpl;
import jp.tcmobile.bamboo.service.UserAnswerServiceImpl;

@Controller
public class ArticleController {
	@Autowired 
	ArticleServiceImpl articleServiceImpl;

	@Autowired 
	UserRepository userRepository;
	
	@Autowired 
	ChoiceRepository choiceRepository;
	
	@Autowired 
	UserAnswerServiceImpl userAnswerServiceImpl;

	//全カテゴリー全ステータスの課題解答をページ表示する画面へのリダイレクト
	@GetMapping({"article/category_all","/article/category_all/status_all","article/","article/category_all/page1"})
	public ModelAndView redirectCategory_all() {
		return new ModelAndView("redirect:/article/category_all/status_all/page1") ;
	}

	//全カテゴリー全ステータスの課題解答をページ表示する画面
	@GetMapping("article/category_all/status_all/page{page_id}")
	public ModelAndView showArticlesByAllCategoryAndAllStatus(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("page_id") int page_id
			){
		User user =userRepository.findByAcountName(userDetail.getUsername());
		Page<Article> articles = articleServiceImpl.getArticlePageListByUser_id(page_id, user.getId());
		mav.addObject("value", articles);
		mav.addObject("categoryType","category_all");
		mav.addObject("statusType","status_all");
		mav.setViewName("/article/articlelist");
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);	
		return mav;
	}

	//個別カテゴリー全ステータスの課題解答をページ表示する画面へのリダイレクト
	@GetMapping({"/article/category_id{category_id}","/article/category_id{category_id}/status_all"})
	public ModelAndView redirectCategory_id(
			@PathVariable("category_id") int category_id
			) {
		return new ModelAndView("redirect:/article/category_id{category_id}/status_all/page1");
	}

	//個別カテゴリー全ステータスの課題解答をページ表示する画面
	@GetMapping("/article/category_id{category_id}/status_all/page{page_id}")
	public ModelAndView showUserPageArticleByAllCategoryAndOneStatus(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("category_id") int category_id,
			@PathVariable("page_id") int page_id
			){
		User user =userRepository.findByAcountName(userDetail.getUsername());
		Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategory(page_id, user.getId(), category_id);
		mav.addObject("value", articles);
		
		
		mav.addObject("categoryType","category_id"+category_id);
		mav.addObject("statusType","status_all");
		mav.setViewName("/article/articlelist");
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);	
		return mav;
	}

	//全カテゴリー個別ステータスの課題解答をページ表示する画面へのリダイレクト
	@GetMapping({"/article/category_all/status_id{status_id}"})
	public ModelAndView redirectAllCategoryAndOneStatus(
			@PathVariable("status_id") int status_id
			) {
		return new ModelAndView("redirect:/article/category_all/status_id{status_id}/page1");
	}


	//全カテゴリー個別ステータスの課題解答をページ表示する画面
	@GetMapping("/article/category_all/status_id{status_id}/page{page_id}")
	public ModelAndView showUserPageArticleByStatusAndCategory(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("status_id") int status_id,
			@PathVariable("page_id") int page_id
			){
		User user =userRepository.findByAcountName(userDetail.getUsername());
		Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndStatusId(page_id, user.getId(), status_id);
		mav.addObject("value", articles);
		mav.addObject("categoryType","category_all");
		mav.addObject("statusType","status_id"+status_id);
		mav.setViewName("/article/articlelist");
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);	
		return mav;
	}

	//個別カテゴリー個別ステータスの課題解答をページ表示する画面へのリダイレクト
	@GetMapping({"/article/category_id{category_id}/status_id{status_id}"})
	public ModelAndView redirectOneCategoryOneStatus(
			@PathVariable("category_id") int category_id,
			@PathVariable("status_id") int status_id
			) {
		return new ModelAndView("redirect:/article/category_id{category_id}/status_id{status_id}/page1");
	}

	//個別カテゴリー個別ステータスの課題解答をページ表示する画面
	@GetMapping("/article/category_id{category_id}/status_id{status_id}/page{page_id}")
	public ModelAndView showUserArticleByStatusAndCategoryAndStatus(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("status_id") int status_id,
			@PathVariable("category_id") int category_id,
			@PathVariable("page_id") int page_id
			){
		User user =userRepository.findByAcountName(userDetail.getUsername());
		Page<Article> articles = articleServiceImpl.getArticlePageListByUser_idAndCategoryAndStatusId(page_id, user.getId(), category_id, status_id);
		mav.addObject("value", articles);
		mav.addObject("categoryType","category_id"+category_id);
		mav.addObject("statusType","status_id"+status_id);
		mav.setViewName("/article/articlelist");
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);	
		return mav;
	}
	
	//個別カテゴリー個別ステータスの課題解答をページ表示する画面へのリダイレクト
	@GetMapping({"/article{article_id}","/article/category_id{category_id}/status_all/{article_id}","/article/category_all/status_id{status_id]/{article_id}"})
	public ModelAndView redirectArticle(
			@PathVariable("article_id") int article_id
			) {
		Article article = articleServiceImpl.getArticleById(article_id);
		return new ModelAndView("redirect:/article/category_id"+article.getTest().getCategory().getId()+"/status_id"+article.getStatusId()+"/"+article_id);
	}

	//課題解答詳細ページを表示する画面
	@GetMapping("/article/category_id{category_id}/status_id{status_id}/{article_id}")
	public ModelAndView showArticle(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("status_id") int status_id,
			@PathVariable("category_id") int category_id,
			@PathVariable("article_id") int article_id
			){
		Article article = articleServiceImpl.getArticleById(article_id);
		mav.addObject("article", article);
		mav.setViewName("article/article");
		
		//権限の付与
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		mav.addObject("isAdmin", isAdmin);
		
		//アカウント名の登録
		String accountName = userDetail.getUsername();
		mav.addObject("accountName", accountName);	
		
		//ユーザ解答情報の登録
		List<UserAnswer> userAnswers = new ArrayList<UserAnswer>();
		mav.addObject("userAnswers",userAnswers);
		return mav;
	}

	//課題解答詳細ページから課題解答表示画面へのリダイレクト
	@PostMapping("/article/category_id{category_id}/status_id{status_id}/{article_id}")
	public ModelAndView submitArticle(
			@PathVariable("article_id") int article_id,
			@AuthenticationPrincipal UserDetail userDetail,
			@RequestParam("userAnswers.choiceList") List<Integer> choicelists
			) {
		Article article = articleServiceImpl.getArticleById(article_id);
		//状態を解答済みにする
		article.setStatusId(2);
		articleServiceImpl.saveArticle(article);
		
		//userAnswerテーブルへ登録
		for(Problem p: article.getTest().getProblemList()) {
			UserAnswer userAnswer = new UserAnswer();
			//問題登録
			userAnswer.setProblem(p);
			//アカウント名登録
			userAnswer.setUser(userRepository.findByAcountName(userDetail.getUsername()));
			
			//！！problemエンティティからもuserエンティティからも登録の必要
			//選択肢リストを登録
			List<Integer> choiceAnswerList = new ArrayList<Integer>();
			for(int i:choicelists) {
				Choice c = choiceRepository.getOne(i);
				//問題番号が一致するか
				if(c.getProblem().getId() == p.getId()) {
					choiceAnswerList.add(i);
				}
			}
			userAnswer.setChoiceList(choiceAnswerList);
			userAnswerServiceImpl.saveUserAnswer(userAnswer);
		}
		
		return new ModelAndView("redirect:/article/category_id"+article.getTest().getCategory().getId()+"/status_id"+article.getStatusId()+"/answer"+article.getId());
	}

	//課題解答表示画面
	@GetMapping("/article/category_id{category_id}/status_id{status_id}/answer{article_id}")
	public ModelAndView showAnswer(
			ModelAndView mav,
			@AuthenticationPrincipal UserDetail userDetail,
			@PathVariable("article_id") int article_id
			){
		Article article = articleServiceImpl.getArticleById(article_id);
		mav.addObject("article", article);
		mav.setViewName("article/articleanswer");
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);
		//mav.addObject("userAnswer", userAnswer);
		return mav;
	}	
	

//	@PostMapping("/article/category_id{category_id}/status_id{status_id}/{article_id}")
//	public ModelAndView saveUserAnswer(ModelAndView mav,
//			@AuthenticationPrincipal UserDetail userDetail,
//			UserAnswer userAnswer,
//			Article article){
//		if(userAnswerServiceImpl.isAnswered(article)) {
//			throw new IllegalArgumentException("解答済みです。");//例外処理
//		}
//		userAnswerServiceImpl.saveUserAnswer(userAnswers);
//		mav.addObject("userAnswer", userAnswer);
//		mav.addObject("article", article);
//		mav.setViewName("article/articleanswer");
//		return mav;
//	}



}