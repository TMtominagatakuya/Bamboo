package jp.tcmobile.bamboo.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jp.tcmobile.bamboo.model.Authentication;
import jp.tcmobile.bamboo.model.Authorization;
import jp.tcmobile.bamboo.model.Authorization.Role;
import jp.tcmobile.bamboo.model.User;
import jp.tcmobile.bamboo.repository.UserRepository;
import jp.tcmobile.bamboo.service.AuthWrapper;
import jp.tcmobile.bamboo.service.TestServiceImpl;
import jp.tcmobile.bamboo.service.UserDetail;
import jp.tcmobile.bamboo.service.UsersServiceImpl;

@Controller
public class UserController {

	@Autowired
	TestServiceImpl testServiceImpl;
	
	@Autowired
	UsersServiceImpl usersServiceImpl;
	
	@Autowired
	UserRepository userRepository;
	
	

	@RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
	public ModelAndView login(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
		System.out.println(bCrypt.encode("ccsakura"));
		return modelAndView;
	}
	
	@GetMapping("/index")
	public ModelAndView showHome( @AuthenticationPrincipal UserDetail userDetail){
	    ModelAndView mav;
	    boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
	    boolean isStaff = userDetail.getAuthorities().toString().contains(Role.staff.toString());
	        if(isAdmin) {
	            mav = new ModelAndView("redirect:test/testlist/category_all/page1");
	            
	        }
	        else if(isStaff) {
	            mav = new ModelAndView ("redirect:/article/category_all/page1");
	        }
	        else {
	            //後で失敗用のビューを追加
	            mav = new ModelAndView();
	            mav.setViewName("error");
	        }
	    return mav;
	}
	
	// ユーザ一覧画面
	@GetMapping("/users/userlist")
	public ModelAndView showUsersList(@AuthenticationPrincipal UserDetail userDetail, ModelAndView mav) {
		mav.setViewName("users/userlist");
		List<User> userlist = userRepository.findAll();
		mav.addObject("userlist", userlist);
		List<AuthWrapper> authWrapperList = new ArrayList<AuthWrapper>();
		for(User user : userlist) {
			Set<Authorization> authSet = user.getAuthorizationSet();
			List<Authorization> authList = new ArrayList<Authorization>(authSet);
			AuthWrapper authWrapper = new AuthWrapper();
			authWrapper.setRole(authList.get(0).getRole().toString());
			authWrapperList.add(authWrapper);
		}
		mav.addObject("authWrapperList",authWrapperList);
		
		boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
		String accountName = userDetail.getUsername();
		mav.addObject("isAdmin", isAdmin);
		mav.addObject("accountName", accountName);	
		return mav;
	}
	
	// ユーザ新規登録画面
		@GetMapping("/users/adduser")
		public ModelAndView showUsersAdd(@AuthenticationPrincipal UserDetail userDetail, ModelAndView mav) {
			mav.setViewName("users/adduser");
			User user = new User();
			Authorization auth = new Authorization();
			mav.addObject("user", user);
			mav.addObject("auth", auth);
			boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
			String accountName = userDetail.getUsername();
			mav.addObject("isAdmin", isAdmin);
			mav.addObject("accountName", accountName);	
			return mav;
		}
		
		@PostMapping(value= "/users/adduser")
		public ModelAndView saveUsers(@AuthenticationPrincipal UserDetail userDetail, @ModelAttribute("user") @Validated User user, Authorization auth, BindingResult result, ModelAndView mav) {
			if(!result.hasErrors()) {
				usersServiceImpl.createUser(user, auth);
				mav = new ModelAndView ("redirect:/users/userlist");
			} else {
				mav.addObject("msg", "sorry, error is occured...");
			}
			boolean isAdmin = userDetail.getAuthorities().toString().contains(Role.admin.toString());
			String accountName = userDetail.getUsername();
			mav.addObject("isAdmin", isAdmin);
			mav.addObject("accountName", accountName);	
			return mav;
		}
		
	// ユーザ―編集画面
//		@GetMapping("/usersedit")
//		public ModelAndView showUsersEdit(ModelAndView mav) {
//			mav.setViewName("users/usersedit");
//			return mav;
//		}
		
//		@PostConstruct
//		public void init() {
//			User user = new User();
//			user.setAccountName("kim");
//			user.setMailAddress("t.kim@tcmobile.jp");
//			user.setName("taejin");
//			BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
//			user.setPassword(bCrypt.encode("ccsakura"));
//			user.setArticleList(null);
//			
//			Authentication auth = new Authentication();
//			auth.setUser(user);
//			auth.setAccountName(user.getAccountName());
//			auth.setPassword(user.getPassword());
//			Date date = Date.valueOf("2018-12-31");
//			auth.setValidDate(date);
//			user.setAuthentication(auth);
//			
//			Set<Authorization> authorizationSet = new HashSet<Authorization>();
//			Authorization a = new Authorization();
//			a.setRole(Authorization.Role.admin);
//			a.setName("admin");
//			Set<User> userSet = new HashSet<User>();
//			userSet.add(user);
//			a.setUserSet(userSet);
//			authorizationSet.add(a);
//			user.setAuthorizationSet(authorizationSet);
//			
//			userRepository.saveAndFlush(user);
//			
//		}

}