package jp.tcmobile.bamboo.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import jp.tcmobile.bamboo.model.Article;
import jp.tcmobile.bamboo.model.Authentication;
import jp.tcmobile.bamboo.model.Authorization;
import jp.tcmobile.bamboo.model.Authorization.Role;
import jp.tcmobile.bamboo.model.Test;
import jp.tcmobile.bamboo.model.User;
import jp.tcmobile.bamboo.repository.ArticleRepository;
import jp.tcmobile.bamboo.repository.UserRepository;

@Service
public class UsersServiceImpl implements UsersService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ArticleServiceImpl articleServiceImpl;
	
	@Autowired
	TestServiceImpl testServiceImpl;

	public void saveTest(User user) {
		userRepository.saveAndFlush(user);
	}
	
	public User emptyUser() {
		User user = new User();
		//Authorizationを読み込み、userにsetする。そのauthrizatinoにuserをセットする。
		//Authenticationを読み込み、userとつなげる
		return user;
	}
	
	public void createUser(User user, Authorization a) {
		String passtmp = user.getPassword();
		BCryptPasswordEncoder bCrypt = new BCryptPasswordEncoder();
		user.setPassword(bCrypt.encode(passtmp));
		
		Authentication auth = new Authentication();
		auth.setUser(user);
		auth.setAccountName(user.getAccountName());
		auth.setPassword(user.getPassword());
		Date date = Date.valueOf("2018-12-31");
		auth.setValidDate(date);
		user.setAuthentication(auth);
		
		Set<Authorization> authorizationSet = new HashSet<Authorization>();
		if(a.getRole().equals(Role.admin)) a.setName("admin");
		else if(a.getRole().equals(Role.staff)) a.setName("staff");
		
		Set<User> userSet = new HashSet<User>();
		userSet.add(user);
		a.setUserSet(userSet);
		authorizationSet.add(a);
		user.setAuthorizationSet(authorizationSet);
		
		userRepository.saveAndFlush(user);
		
		List<Article> articleList = new ArrayList<Article>();
		List<Test> testList = new ArrayList<Test>();
		testList = testServiceImpl.getTestList();
		for(Test test : testList) {
			Article article = new Article();
			article.setStatusId(0);
			article.setTest(test);
			article.setUser(user);
			articleList.add(article);
			articleServiceImpl.saveArticle(article);
		}
		user.setArticleList(articleList);
	}
}
