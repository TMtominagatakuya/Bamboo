package jp.tcmobile.bamboo.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthWrapper {
	String role;
}
