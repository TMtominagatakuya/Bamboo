package jp.tcmobile.bamboo.service;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ListTarget {
	private int targetId = -1;
}
