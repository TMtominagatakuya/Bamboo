package jp.tcmobile.bamboo.model;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Authentication {
	
	@Id
	@Column(name = "account_name", length = 30, nullable=false,unique = true)
	private String accountName;
	
	@Column(name = "password", length = 100, nullable=false)
	private String password;
	
	@Column(name = "valid_date", length = 100, nullable=false)
	private java.sql.Date validDate;
	
	@OneToOne(optional = false, cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id", referencedColumnName = "id")
	private User user;
}